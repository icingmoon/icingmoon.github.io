L = 32  # The length of the vector
M = 2**256  # The upper bound of the elements in the vector
N = 518  # The bit length of primes (should be greater than log2(M**2 * L)
