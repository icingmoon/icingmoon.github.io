import os
import random
import base64
import sys
import signal
import hashlib
import string
from flag import FLAG

sys.stdout = open(sys.stdout.fileno(), mode='w', buffering=1, encoding='utf-8')
sys.stdin = open(sys.stdin.fileno(), mode='r', buffering=1, encoding='utf-8')

def encode_image_to_base64(file_path):
    with open(file_path, 'rb') as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return encoded_string.decode('utf-8')

# Define the signal handler for the alarm
def signal_handler(signum, frame):
    raise Exception("Time is up!")

# Set up the signal to catch SIGALRM and use the handler
signal.signal(signal.SIGALRM, signal_handler)

def generate_pow_challenge(difficulty=4):
    challenge = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    prefix = "0" * difficulty
    print(f"PoW Challenge: SHA256(solution + '{challenge}') must start with '{prefix}'.")
    return challenge, prefix

def verify_pow_solution(challenge, solution, prefix):
    guess = solution + challenge
    guess_hash = hashlib.sha256(guess.encode()).hexdigest()
    return guess_hash.startswith(prefix)

def play_game():
    # PoW challenge
    challenge, prefix = generate_pow_challenge(difficulty=4)  # Difficulty can be adjusted
    solution = input("Enter PoW solution: ").strip()
    if not verify_pow_solution(challenge, solution, prefix):
        print("Invalid PoW solution. Access denied.")
        return
    else:
        print("PoW solution accepted. Starting the game...")

    try:
        correct_answers = []  # List to store the correct answers
        for _ in range(20):  # 20 rounds of the game
            files = [f for f in os.listdir('folder') if os.path.isfile(os.path.join('folder', f))]
            chosen_file = random.choice(files)
            file_path = os.path.join('folder', chosen_file)
            correct_answer = chosen_file[-1].upper()
            correct_answers.append(correct_answer)  # Store the correct answer
            
            encoded_image = encode_image_to_base64(file_path)
            print(f"Round {_+1}: Is this picture real or not (Y/N)? \n{encoded_image}\n")
        
        # Set an alarm for 10 seconds before input
        signal.alarm(10)
        data = input("Enter your answers for all 20 rounds (Y/N): ").strip().upper()
        signal.alarm(0)  # Cancel the alarm if input is received in time

        if len(data) != 20:
            print("Invalid input. You must enter exactly 20 characters (Y/N). Game over.\n")
            return

        for i in range(20):
            if data[i] != correct_answers[i]:
                print(f"Incorrect answer. Game over.\n")
                return
            
        print(f"Congratulations! You've completed all rounds correctly. Here is your flag: {FLAG}\n")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    play_game()

