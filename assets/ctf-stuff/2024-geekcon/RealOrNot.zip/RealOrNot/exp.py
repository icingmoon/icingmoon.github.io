from pwn import remote, process, context, log
from pwnlib.util.iters import mbruteforce
from string import ascii_letters, ascii_lowercase, digits
from hashlib import sha256
# this example uses requests
import requests
import json
import base64
import os
import time
import zlib

def crc32(data:bytes) -> str:
    return hex(zlib.crc32(data) & 0xffffffff)[2:].zfill(8)

api_user = "1232298040"
api_secret = "qXcxGNWJhRNTNtCw6PHyybcGA7aqBBP9"

params = {
  'models': 'genai',
  'api_user': f'{api_user}',
  'api_secret': f'{api_secret}'
}

if not os.path.exists("./table.json"):
    table = {}
else:
    with open("table.json", "r") as fio:
        table = json.load(fio)

def check_image(img_path):
    files = {'media': open(img_path, 'rb')}
    r = requests.post('https://api.sightengine.com/1.0/check.json', files=files, data=params)
    output = json.loads(r.text)
    assert "status" in output, f"{output = }"
    assert output["status"] == "success", f"{output = }"
    prob = output["type"]["ai_generated"]
    log.info(f"ai_generated {prob = }")
    return "N" if prob > 0.5 else "Y"

# context.log_level = "DEBUG"

def solve_pow(io:remote):
    io.recvuntil(b" SHA256(solution + '")
    challenge = io.recvuntil(b"') must start with '", drop=True)
    assert len(challenge) == 16, f"{challenge = }"
    prefix = io.recvuntil(b"\n", drop=True).decode()[:-2]
    log.info(f"{challenge  = }, {prefix = }")
    diff = len(prefix)
    log.info(f"{diff = }")
    sol = mbruteforce(lambda x: sha256(x.encode() + challenge).hexdigest().startswith(prefix), ascii_letters + digits, diff + 2)
    log.info(f"solved pow: {sol}")
    io.sendlineafter(b"Enter PoW solution: ", sol.encode())
    return True

def read_image(io:remote):
    log.info(io.recvuntil(b"Is this picture real or not (Y/N)? \n").decode().strip())
    return io.recvline().decode().strip()
# nc -X connect -x instance.chall.geekctf.geekcon.top:18081 4bj3p4t84p4xwf98 1
# nc -X connect -x instance.chall.geekctf.geekcon.top:18081 7v6cweq6tp8wwmt2 1
# nc -X connect -x instance.chall.geekctf.geekcon.top:18081 fx2cec9xkk3qvk33 1
io = process(["nc", "-X", "connect", "-x", "instance.chall.geekctf.geekcon.top:18081", "fx2cec9xkk3qvk33", "1"])
assert solve_pow(io), "pow failed"
log.info(io.recvline().decode().strip())

st = time.time()
sol = ""
cached_hit = 0
for i in range(20):
    b64_dat = read_image(io)
    raw_data_bytes = base64.b64decode(b64_dat)
    fingerprint = crc32(raw_data_bytes)
    if  fingerprint in table:
        ans = table[crc32(base64.b64decode(b64_dat))]
        log.info(f"found {ans = } with cached data")
        sol += ans
        cached_hit += 1
        continue
    
    with open(f"imgs{i}.png", "wb") as fio:
        fio.write(base64.b64decode(b64_dat))
    ans = check_image(f"imgs{i}.png")
    sol += ans
    table[fingerprint] = ans
    et = time.time()
    # remove the file
    os.remove(f"imgs{i}.png")

log.info(f"cached hit: {cached_hit} / {20}")
log.info(f"round {i + 1} total time: {et - st}")

# save the table
with open("./table.json", "w") as fio:
    json.dump(table, fio)

io.sendlineafter(b"Enter your answers for all 20 rounds (Y/N): ", sol.encode())
log.info(io.recvline().decode().strip())
io.close()

