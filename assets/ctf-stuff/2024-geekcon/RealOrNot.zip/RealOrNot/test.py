# this example uses requests
import requests
import json

api_user = "1232298040"
api_secret = "qXcxGNWJhRNTNtCw6PHyybcGA7aqBBP9"

params = {
  'models': 'genai',
  'api_user': f'{api_user}',
  'api_secret': f'{api_secret}'
}
files = {'media': open("./img1.png", 'rb')}
r = requests.post('https://api.sightengine.com/1.0/check.json', files=files, data=params)
output = json.loads(r.text)
print(output)